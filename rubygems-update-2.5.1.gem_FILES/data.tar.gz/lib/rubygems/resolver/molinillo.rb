require 'rubygems/resolver/molinillo/lib/molinillo'
